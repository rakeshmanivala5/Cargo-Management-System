/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bean;

/**
 *
 * @author rakes
 */
public class Billing {
    private int billNo;
    private String billDate;
    private int ShippintCharge;
    private int cid;

    public Billing() {
    }

    public Billing(int billNo, String billDate, int ShippintCharge, int cid) {
        this.billNo = billNo;
        this.billDate = billDate;
        this.ShippintCharge = ShippintCharge;
        this.cid = cid;
    }

    public int getBillNo() {
        return billNo;
    }

    public void setBillNo(int billNo) {
        this.billNo = billNo;
    }

    public String getBillDate() {
        return billDate;
    }

    public void setBillDate(String billDate) {
        this.billDate = billDate;
    }

    public int getShippintCharge() {
        return ShippintCharge;
    }

    public void setShippintCharge(int ShippintCharge) {
        this.ShippintCharge = ShippintCharge;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }
    
    
    
}
