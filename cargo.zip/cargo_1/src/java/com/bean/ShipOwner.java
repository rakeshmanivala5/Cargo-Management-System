/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bean;

/**
 *
 * @author rakes
 */
public class ShipOwner {
    private int so_id;
    private String so_name;
    private String so_address;

    public ShipOwner() {
    }

    public ShipOwner(int so_id, String so_name, String so_address) {
        this.so_id = so_id;
        this.so_name = so_name;
        this.so_address = so_address;
    }

    public int getSo_id() {
        return so_id;
    }

    public void setSo_id(int so_id) {
        this.so_id = so_id;
    }

    public String getSo_name() {
        return so_name;
    }

    public void setSo_name(String so_name) {
        this.so_name = so_name;
    }

    public String getSo_address() {
        return so_address;
    }

    public void setSo_address(String so_address) {
        this.so_address = so_address;
    }
    
    
    
}
