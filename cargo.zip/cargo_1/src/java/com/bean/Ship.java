/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bean;

/**
 *
 * @author rakes
 */
public class Ship {
   private int sid;
   private String sname;
   private int scap;
   private int fhid;
   private int thid;
   private int soid;

    public Ship() {
    }

    public Ship(int sid, String sname, int scap, int fhid, int thid, int soid) {
        this.sid = sid;
        this.sname = sname;
        this.scap = scap;
        this.fhid = fhid;
        this.thid = thid;
        this.soid = soid;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public int getScap() {
        return scap;
    }

    public void setScap(int scap) {
        this.scap = scap;
    }

    public int getFhid() {
        return fhid;
    }

    public void setFhid(int fhid) {
        this.fhid = fhid;
    }

    public int getThid() {
        return thid;
    }

    public void setThid(int thid) {
        this.thid = thid;
    }

    public int getSoid() {
        return soid;
    }

    public void setSoid(int soid) {
        this.soid = soid;
    }
   
   
}
