/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bean;

/**
 *
 * @author rakes
 */
public class THarbour {
    private int th_id;
    private  String th_name;
    private String th_loc;
    private int aid;

    public THarbour() {
    }

    public THarbour(int th_id, String th_name, String th_loc, int aid) {
        this.th_id = th_id;
        this.th_name = th_name;
        this.th_loc = th_loc;
        this.aid = aid;
    }

    public int getTh_id() {
        return th_id;
    }

    public void setTh_id(int th_id) {
        this.th_id = th_id;
    }

    public String getTh_name() {
        return th_name;
    }

    public void setTh_name(String th_name) {
        this.th_name = th_name;
    }

    public String getTh_loc() {
        return th_loc;
    }

    public void setTh_loc(String th_loc) {
        this.th_loc = th_loc;
    }

    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }
    
    
}
