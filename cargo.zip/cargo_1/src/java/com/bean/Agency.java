/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bean;

/**
 *
 * @author rakes
 */
public class Agency {
    
    private int agency_id;
    private String agency_name;
    private int contact_num;
    private String address;
    
   public Agency(){}
    
    public Agency(int aid,String aname,int cno,String add){
    agency_id=aid;
    agency_name=aname;
    contact_num=cno;
    address=add;
    
    } 

    public int getAgency_id() {
        return agency_id;
    }

    public String getAgency_name() {
        return agency_name;
    }

    public int getContact_num() {
        return contact_num;
    }

    public String getAddress() {
        return address;
    }

    public void setAgency_id(int agency_id) {
        this.agency_id = agency_id;
    }

    public void setAgency_name(String agency_name) {
        this.agency_name = agency_name;
    }

    public void setContact_num(int contact_num) {
        this.contact_num = contact_num;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    
}
