/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bean;

/**
 *
 * @author rakes
 */
public class FHarbour {
    private int fh_id;
    private  String fh_name;
    private String fh_loc;
    private int aid;

    public FHarbour() {
    }

    public FHarbour(int fh_id, String fh_name, String fh_loc, int aid) {
        this.fh_id = fh_id;
        this.fh_name = fh_name;
        this.fh_loc = fh_loc;
        this.aid = aid;
    }

    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }

    

    public int getFh_id() {
        return fh_id;
    }

    public void setFh_id(int fh_id) {
        this.fh_id = fh_id;
    }

    public String getFh_name() {
        return fh_name;
    }

    public void setFh_name(String fh_name) {
        this.fh_name = fh_name;
    }

    public String getFh_loc() {
        return fh_loc;
    }

    public void setFh_loc(String fh_loc) {
        this.fh_loc = fh_loc;
    }
    
}
