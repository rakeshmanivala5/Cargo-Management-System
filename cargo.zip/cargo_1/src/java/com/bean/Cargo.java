/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bean;

import java.sql.Date;

/**
 *
 * @author rakes
 */
public class Cargo {
   private int cid;
   private String cname;
   private int cprice;
   private int cweight;
   private String status;
   private int sid;
   private int custId;
   private Date dDate;

    public Date getdDate() {
        return dDate;
    }

    public void setdDate(Date dDate) {
        this.dDate = dDate;
    }

    public Cargo() {
    }

    public Cargo(int cid, String cname, int cprice, int cweight, String status, int sid, int custId) {
        this.cid = cid;
        this.cname = cname;
        this.cprice = cprice;
        this.cweight = cweight;
        this.status = status;
        this.sid = sid;
        this.custId = custId;
    }

    public Cargo(int aInt, String string, String aInt0, Date date) {
        this.cid=aInt;
        this.cname=string;
        this.status=aInt0;
        this.dDate=date;
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public int getCprice() {
        return cprice;
    }

    public void setCprice(int cprice) {
        this.cprice = cprice;
    }

    public int getCweight() {
        return cweight;
    }

    public void setCweight(int cweight) {
        this.cweight = cweight;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }
   
   
}
