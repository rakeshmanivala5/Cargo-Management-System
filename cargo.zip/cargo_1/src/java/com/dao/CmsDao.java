/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.bean.Agency;
import com.bean.Billing;
import com.bean.Cargo;
import com.bean.Customer;
import com.bean.FHarbour;
import com.bean.Ship;
import com.bean.ShipOwner;
import com.bean.THarbour;
import com.util.DatabaseUtil;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rakes
 */
public class CmsDao {
    
    public ArrayList<Agency> getAllAgencies()
    {
        
       ArrayList<Agency> agencies = new ArrayList<>();
       
       Connection con = DatabaseUtil.getConnection();
       String qry="select * from agency";
        try {
            PreparedStatement ps=con.prepareStatement(qry);
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               Agency agency=new Agency(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4));
               agencies.add(agency);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return agencies;
    }

    public ArrayList<FHarbour> getAllFHarbour() {
       ArrayList<FHarbour> fhs = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from F_harbour";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               FHarbour fh=new FHarbour(rs.getInt(1), rs.getString(2), rs.getString(3),rs.getInt(4));
               fhs.add(fh);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return fhs;
    }

    public ArrayList<THarbour> getAllTHarbour() {
        ArrayList<THarbour> ths = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from T_harbour";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               THarbour th=new THarbour(rs.getInt(1), rs.getString(2), rs.getString(3),rs.getInt(4));
               ths.add(th);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return ths;
    }

    public ArrayList<ShipOwner> getAllOwners() {
         ArrayList<ShipOwner> owners = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from ship_owner";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               ShipOwner owner=new ShipOwner(rs.getInt(1), rs.getString(2), rs.getString(3));
               owners.add(owner);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return owners;
    }

    public ArrayList<Cargo> getCargoByShip(int sid) {
        ArrayList<Cargo> cl = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from Cargo where s_id=?";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            ps.setInt(1, sid);
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               Cargo c=new Cargo(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getInt(7));
               cl.add(c);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return cl;
    }

    public ArrayList<Cargo> getCargoByStatus(String status) {
         ArrayList<Cargo> cl = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from Cargo where c_status=?";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            ps.setString(1, status);
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               Cargo c=new Cargo(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getInt(7));
               cl.add(c);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return cl;
    }

    public ArrayList<Cargo> getAllCargo() {
         ArrayList<Cargo> cl = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from Cargo";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               Cargo c=new Cargo(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getInt(7));
               cl.add(c);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return cl;
       
    }

    public ArrayList<Ship> getAllShips() {
        ArrayList<Ship> ships = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from ship";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               Ship s=new Ship(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4),rs.getInt(5),rs.getInt(6));
               ships.add(s);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return ships;
    }

    public ArrayList<Customer> getAllCutomers() {
        ArrayList<Customer> custs = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from customer";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               Customer c=new Customer(rs.getInt(1), rs.getString(2), rs.getString(3));
               custs.add(c);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return custs;
        
    }

    public ArrayList<Billing> getAllBills() {
        ArrayList<Billing> bills = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from billing";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               Billing bill=new Billing(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4));
               bills.add(bill);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return bills;
    }

    public Cargo getCargoById(int cid) {
         Cargo c = new Cargo();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from Cargo where c_id=?";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            ps.setInt(1, cid);
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               c=new Cargo(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getInt(7));
               
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return c;
    }

    public boolean updateCargo(Cargo uc) {
        boolean updated=false;
        Connection con = DatabaseUtil.getConnection();
        String qry="update cargo set c_price=?, c_weight=?, c_status=? where c_id=?";
        try {
            PreparedStatement ps=con.prepareStatement(qry);
            ps.setInt(1, uc.getCprice());
            ps.setInt(2, uc.getCweight());
            ps.setString(3, uc.getStatus());
            ps.setInt(4, uc.getCid());
            int i=ps.executeUpdate();
            if(i>0) updated=true;
            
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return updated;
    }

    public ArrayList<Integer> getCargoIds() {
       ArrayList<Integer> ids = new ArrayList<>();
       Connection con = DatabaseUtil.getConnection();
       String qry="select c_id from cargo";
        try {
            PreparedStatement ps=con.prepareStatement(qry);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                ids.add(rs.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return ids;
    }

    public Customer isCustPresent(int id, String pwd) {
        Customer cust=new Customer();
        Connection con = DatabaseUtil.getConnection();
        String qry="select * from customer where cust_id=? and pwd=?";
        PreparedStatement ps=null;
        try {
            ps = con.prepareStatement(qry);
            ps.setInt(1,id);
            ps.setString(2,pwd);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
              cust = new Customer(id, rs.getString(2), rs.getString(3));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return cust;
    }
    
    public ArrayList<Integer> getShipIDs(){
        ArrayList<Integer> ships = new ArrayList<>();
        
        Connection con = DatabaseUtil.getConnection();
       String qry="select s_id from ship ";
        try {
            PreparedStatement ps=con.prepareStatement(qry);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                ships.add(rs.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        return ships;
    }

    public int addCargo(Cargo cargo) {
       Connection con = DatabaseUtil.getConnection();
       int added=0;
       String qry="insert into cargo values(?,?,?,?,'packed',?,?)";
       String q2="select s.s_id from cargo c, ship s where c.s_id=s.s_id and c.s_id=? and s.s_cap >= (select  sum(c_weight) from cargo c1 where c1.s_id=?);";
       PreparedStatement ps = null;
        try {
            ps=con.prepareStatement(qry);
            ps.setInt(1, cargo.getCid());
            ps.setString(2,cargo.getCname());
            ps.setInt(3, cargo.getCprice());
            ps.setInt(4, cargo.getCweight());
           // ps.setString(5, cargo.getStatus());
            ps.setInt(5, cargo.getSid());
            ps.setInt(6,cargo.getCustId());
            added=ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return added;
    }

    public int deleteCargo(int cid) {
     int del =0;
     
     Connection con = DatabaseUtil.getConnection();
     String qry="delete from cargo where c_id=?";
            PreparedStatement ps = null;
        try {
            ps=con.prepareStatement(qry);
            ps.setInt(1,cid);
            del = ps.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }

     return del;
    }

    public int setCustId(int custId) {
        Connection con = DatabaseUtil.getConnection();
        String qry="update custID set custid=? where count=1";
        PreparedStatement ps=null;
        int i=0;
        try {
            ps=con.prepareStatement(qry);
            ps.setInt(1,custId);
            i=ps.executeUpdate();
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i;
    }
    
    public int getCustId(){
        int custId =0;
        Connection con = DatabaseUtil.getConnection();
        String qry="select custid from custID";
        PreparedStatement ps = null;
        try {
            System.out.print("\n inside try dao");
            ps=con.prepareStatement(qry);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
                custId=rs.getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.print("\n Cust ID in getCustId "+custId);
        return custId;
    }

    public ArrayList<Cargo> getCustCargo(int custid) {
        ArrayList<Cargo> cl = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from Cargo where cust_id=?";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            ps.setInt(1, custid);
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               Cargo c=new Cargo(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getInt(7));
               cl.add(c);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return cl;
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public ArrayList<Cargo> getCargoByCust(int custid){
        ArrayList<Cargo> cl = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select * from Cargo where cust_id=?";
       try {
            PreparedStatement ps=con.prepareStatement(qry);
            ps.setInt(1, custid);
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
               Cargo c=new Cargo(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getInt(7));
               cl.add(c);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return cl;
    }  
    
    public ArrayList<Integer> getCargoIdsByCust(int custid){
        ArrayList<Integer> ids = new ArrayList<>();
       Connection con = DatabaseUtil.getConnection();
       String qry="select c_id from cargo where cust_id=?";
        try {
            PreparedStatement ps=con.prepareStatement(qry);
            ps.setInt(1, custid);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                ids.add(rs.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return ids;
    }

    
    public ArrayList<Integer> getCustIDs(){
        ArrayList<Integer> ids = new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
       String qry="select cust_id from customer ";
        try {
            PreparedStatement ps=con.prepareStatement(qry);
           
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                ids.add(rs.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ids;
    }
    
    public ArrayList<Cargo> getStatus(int cid){
        ArrayList<Cargo> cl =  new ArrayList<>();
        Connection con = DatabaseUtil.getConnection();
        String qry="select * from cargo_status where cust_id=?";
        try {
            PreparedStatement ps = con.prepareStatement(qry);
            ps.setInt(1, cid);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                /*java.util.Date date = Calendar.getInstance().getTime(); 
                date=rs.getDate(5);
                System.out.println(date);
                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
                String strDate = dateFormat.format(date);  
                System.out.println("Date "+strDate);*/
                Cargo c = new Cargo(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDate(5));
                cl.add(c);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CmsDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return cl;
    }
}
