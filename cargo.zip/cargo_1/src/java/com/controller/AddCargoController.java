/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.bean.Cargo;
import com.bean.Customer;
import com.dao.CmsDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author rakes
 */
@WebServlet(name = "AddCargoController", urlPatterns = {"/AddCargoController"})
public class AddCargoController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddCargoController</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AddCargoController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
        doPost(request, response);
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        CmsDao dao = new CmsDao();
        int cid = Integer.parseInt(request.getParameter("cid"));
        String cname=request.getParameter("cname");
        int cprice = Integer.parseInt(request.getParameter("cp"));
        int cweight = Integer.parseInt(request.getParameter("cw"));
        String status = request.getParameter("status");
        int shipId = Integer.parseInt(request.getParameter("sid"));
        int custid = Integer.parseInt(request.getParameter("custid"));
        Cargo cargo = new Cargo(cid, cname, cprice, cweight, status, shipId, custid);
        int added = dao.addCargo(cargo);
        System.out.println("Added "+added);
        PrintWriter out = response.getWriter();
        if(added==1){
            
            out.print("<html>\n" +
"    <head>\n" +
"        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
"        <title>JSP Page</title>\n" +
"    <style> \n" +
"        div {color:blue;\n" +
"        background-color:lightblue;\n" +
"        height:100px;\n" +
"                   \n" +
"        }\n" +
"        \n" +
"        \n" +
"         #ve{\n" +
"            text-align: right;\n" +
"            text-align: end;\n" +
"            float: right;   \n" +
"        }\n" +
"        </style>\n" +
"    </head>\n" +
"    <body>\n" +
"        \n" +
"        <div> \n" +
"            \n" +
"    <center><h1>Cargo Management System</h1></center>\n" +
"    <span id=\"ve\"><a href=\"loginpage.html\">logout</a></span>\n" +

"    <center>\n" +
"    \n" +
"    <a href=\"add_cargo.jsp\">Add Cargo</a>&emsp;\n" +
"    <a href=\"CargoCustController\">View Cargo</a>&emsp;\n" +
"    <a href=\"update_custcargo.jsp\">Update Cargo</a>&emsp;\n" +
"    <a href=\"del_cargo.jsp\">Delete Cargo</a>&emsp;\n"+
    "<a href=\"view_cargo_status.jsp\">Cargos Delivered</a></center>\n" +
"    \n" +
"\n" +
"        </div>\n" +
"         <br><br>  \n" +
"    </body>\n" +
"</html>");
            out.print("<h2>");
            out.print(cargo.getCname()+" Added Successfully</h2>");
        }
        else{
            RequestDispatcher rd = rd=request.getRequestDispatcher("error.jsp");
            rd.forward(request, response);
        } 
        out.print("<html>\n" +
"    <head>\n" +
"        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
"        <title>JSP Page</title>\n" +
"        <style>\n" +
"            h3 {color:blanchedalmond;\n" +
"        height:100px;\n" +
"                   background-image: url(\"resources/nature.jpg\");\n" +
"        position:  absolute;\n" +
"        bottom:10px;\n" +
"        width: 100%;\n" +
"        height: 35px;\n" +
"        \n" +
"        \n" +
"        \n" +
"        }\n" +
"        </style>\n" +
"    </head>\n" +
"    \n" +
"    <body>\n" +
"        <h3><center>Vivekananda Institute of technology</center></h3>\n" +
"                \n" +
"\n" +
"    </body>\n" +
"</html>");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
