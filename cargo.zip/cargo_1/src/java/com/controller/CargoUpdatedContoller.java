/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.bean.Cargo;
import com.dao.CmsDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rakes
 */
@WebServlet(name = "CargoUpdatedContoller", urlPatterns = {"/CargoUpdatedContoller"})
public class CargoUpdatedContoller extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CargoUpdatedContoller</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CargoUpdatedContoller at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
         PrintWriter out = response.getWriter();
         out.print("<html>\n" +
"    <head>\n" +
"        \n" +
"        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
"        <title>header</title>\n" +
"        <style> \n" +
"        div {color:blue;\n" +
"        background-color:lightblue;\n" +
"        height:100px;\n" +
"                   \n" +
"        }\n" +
"        \n" +
"        \n" +
"         #ve{\n" +
"            text-align: right;\n" +
"            text-align: end;\n" +
"            float: right;   \n" +
"        }h2{{color:blue}\n" +
"        </style>\n" +
"    </head>\n" +
"    <body>\n" +
"        \n" +
"        <div> \n" +
"            \n" +
"    <center><h1>Cargo Management System</h1></center>\n" +
"    <span id=\"ve\"><a href=\"loginpage.html\">logout</a></span>\n" +
"    <a href=\"welcome.jsp\">home</a>\n" +
"    <center><span ><a href=\"cargo_views.jsp\">View Cargo</a>&emsp;</span>\n" +
"        <span ><a href=\"UpdateSupportController\"> Update Cargo details </a>&emsp;</span>\n" +
"    <span ><a href=\"entity_views.jsp\">View other Entities</a></span></center>\n" +
"       \n" +
"\n" +
"        </div>\n" +
"        <br><br>\n" +
"    </body>\n" +
"    \n" +
"</html>\n" +
"");
         HttpSession session = request.getSession();
        Cargo cargo=(Cargo) session.getAttribute("obj");
        out.print("<h2>"+cargo.getCname());
        //System.out.println(cargo.getCname());
        int cid=cargo.getCid();
        String cname=cargo.getCname();
        int price=Integer.parseInt(request.getParameter("cp"));
        int weight=Integer.parseInt(request.getParameter("cw"));
        String status=request.getParameter("cs");
        int sid=cargo.getSid();
        int custid=cargo.getCustId();
        Cargo uc = new Cargo(cid, cname, price, weight, status, sid, custid);
        CmsDao dao = new CmsDao();
        boolean updated=dao.updateCargo(uc);
       
        if(updated) out.print(" Updated Successfully</h2>");
        else out.print("No record found");
        out.print("<html>\n" +
"    <head>\n" +
"        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
"        <title>JSP Page</title>\n" +
"        <style>\n" +
"            h3 {color:black;\n" +
"        height:100px;\n" +
"                   background-image: url(\"resources/nature.jpg\");\n" +
"        position:  absolute;\n" +
"        bottom:10px;\n" +
"        width: 100%;\n" +
"        height: 35px;\n" +
"        \n" +
"        \n" +
"        \n" +
"        }\n" +
"        </style>\n" +
"    </head>\n" +
"    \n" +
"    <body>\n" +
"        <h3><center>Vivekananda Institute of technology</center></h3>\n" +
"                \n" +
"\n" +
"    </body>\n" +
"</html>");
    
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
